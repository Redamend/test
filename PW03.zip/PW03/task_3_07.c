#include <stdio.h>
#include <string.h>

#define DISTRO "LinuxDistro"
const char RDATE[] = "2026";

int main(void)
{
    printf("DISTRO: %s\n", DISTRO);
    printf("RDATE: %s\n", RDATE);
    printf("STRLEN: %zu\n", strlen(DISTRO));
    printf("SIZEOF: %zu\n", sizeof(DISTRO));
    return 0;
}
