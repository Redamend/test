#include <stdio.h>

int main(void)
{
    char str[128];
    int width;

    scanf("%127s %d", str, &width);

    printf("%*s\n", width, str);
    printf("%-*s\n", width + 5, str);
    return 0;
}
