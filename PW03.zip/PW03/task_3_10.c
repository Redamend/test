#include <stdio.h>
#include <wchar.h>
#include <locale.h>

int main(void)
{
    wchar_t m1[64], m2[64], m3[64];

    setlocale(LC_ALL, "");

    wscanf(L"%63ls %63ls %63ls", m1, m2, m3);
    wprintf(L"%-15ls|%20ls|%.5ls\n", m1, m2, m3);
    return 0;
}
