#include <stdio.h>
#include <string.h>

int main(void)
{
    char name[64];
    int len;

    scanf("%63s", name);
    len = (int)strlen(name);

    printf("\"%s\"\n", name);
    printf("\"%20s\"\n", name);
    printf("\"%-20s\"\n", name);
    printf("\"%*s\"\n", len + 5, name);
    return 0;
}
