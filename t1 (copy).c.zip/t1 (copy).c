#include <stdio.h>
const int k = 1000;
int main(void) {
    int a = 0, b = 0, c =0;
    int t = 0;
    while (t != 1) {
        if (scanf("%d", &a) == 1) {
            if (a >= 0) {
                b = a / 1000;
                c = a % 1000;
                printf("Объем\t%d мл\t%d л\t%d мл\t%d\n", a, b, c, k);
            } else  {printf("Число меньше нуля\n");
                    break;}
        } else {printf("EOF\n");
                break;}}
    

    return 0;
}






// Вариант для задания 4.1:      15
//  Вариант для задания 4.2:      22
//  Вариант для задания 4.3:      28
//  Вариант для задания 4.4:      4
//  Вариант для задания 4.5:      8 
